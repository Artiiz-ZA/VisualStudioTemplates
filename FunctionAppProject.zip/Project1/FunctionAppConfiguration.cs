﻿using System.Net.Http;
using $safeprojectname$.Application;
using $safeprojectname$.Commands;
using FunctionMonkey.Abstractions;
using FunctionMonkey.Abstractions.Builders;

namespace $safeprojectname$
{
    public class FunctionAppConfiguration : IFunctionAppConfiguration
    {
        public void Build(IFunctionHostBuilder builder)
        {
            builder
                .Setup((serviceCollection, commandRegistry) => { serviceCollection.AddApplication(commandRegistry); })
                .Functions(functions => functions // TODO: Add appropriate routes of Function
                    .HttpRoute("v1/", route => route
                        .HttpFunction<Command>(HttpMethod.Get)));
        }
    }
}