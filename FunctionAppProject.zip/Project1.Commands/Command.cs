﻿using AzureFromTheTrenches.Commanding.Abstractions;

namespace $safeprojectname$
{
    public class Command : ICommand
    {
    }
}