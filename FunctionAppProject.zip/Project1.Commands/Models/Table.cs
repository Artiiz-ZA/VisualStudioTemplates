﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using $safeprojectname$.Models.Interfaces;

namespace $safeprojectname$.Models
{
    [Table("Table")] // TODO: Add Actual Table
    public class Table : IEntity
    {
        public Guid Id { get; set; }
    }
}