﻿using System;

namespace $safeprojectname$.Models.Interfaces
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}