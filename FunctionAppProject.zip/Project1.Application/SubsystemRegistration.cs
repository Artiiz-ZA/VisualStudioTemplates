﻿using System;
using AzureFromTheTrenches.Commanding.Abstractions;
using $safeprojectname$.Repositories;
using $safeprojectname$.Repositories.Implementations;
using $safeprojectname$.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$
{
    public static class SubsystemRegistration
    {
        public static IServiceCollection AddApplication(this IServiceCollection serviceCollection,
            ICommandRegistry commandRegistry)
        {
            // TODO: Update Database Connection Strings
            var dbConnectionString = Environment.GetEnvironmentVariable("DbConnectionString");

            // TODO: Update dbContexts and Repository Wrapper to Service Collection
            serviceCollection
                .AddDbContext<RepositoryContext>(o =>
                    o.UseSqlServer(dbConnectionString ?? throw new InvalidOperationException()))
                .AddScoped<IRepositoryWrapper, RepositoryWrapper>();

            commandRegistry.Discover(typeof(SubsystemRegistration).Assembly);
            return serviceCollection;
        }
    }
}