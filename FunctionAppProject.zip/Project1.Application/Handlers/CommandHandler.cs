﻿using System;
using System.Threading.Tasks;
using AzureFromTheTrenches.Commanding.Abstractions;
using $safeprojectname$.Repositories.Interfaces;
using CmdbUpdater.Commands;
using Microsoft.ApplicationInsights;

namespace $safeprojectname$.Handlers
{
    public class CommandHandler : ICommandHandler<Command>
    {
        private static readonly TelemetryClient Log = new TelemetryClient();
        private readonly IRepositoryWrapper _repo;

        public CommandHandler(IRepositoryWrapper repo)
        {
            _repo = repo;
            Log.InstrumentationKey = Environment.GetEnvironmentVariable("AppInsightsKey");
        }

        public Task ExecuteAsync(Command command)
        {
            try
            {
                throw new NotImplementedException();
            }
            catch (Exception e)
            {
                Log.TrackException(e);
                throw;
            }
        }
    }
}