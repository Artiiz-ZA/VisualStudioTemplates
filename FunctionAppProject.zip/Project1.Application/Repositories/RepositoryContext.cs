﻿using Microsoft.EntityFrameworkCore;

namespace $safeprojectname$.Repositories
{
    public class RepositoryContext : DbContext
    {
        public RepositoryContext(DbContextOptions<RepositoryContext> options) : base(options)
        {
        }

        // TODO: Add DbSets
        public DbSet<Table> Table { get; set; }
    }
}