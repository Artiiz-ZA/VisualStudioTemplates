﻿using System;
using System.Collections.Generic;
using System.Linq;
using $safeprojectname$.Repositories.Interfaces.Models;
using CmdbUpdater.Commands.Models;

namespace $safeprojectname$.Repositories.Implementations.Models
{
    public class TableRepository : RepositoryBase<Table>, ITableRepository
    {
        public TableRepository(RepositoryContext repositoryContext) : base(repositoryContext)
        {
        }

        // TODO: Update to actual

        public IEnumerable<Table> GetAll()
        {
            return FindAll()
                .OrderBy(t => t.Id);
        }

        public Table GetById(Guid id)
        {
            return FindByCondition(t => t.Id.Equals(id))
                .DefaultIfEmpty(new Table())
                .FirstOrDefault();
        }
    }
}