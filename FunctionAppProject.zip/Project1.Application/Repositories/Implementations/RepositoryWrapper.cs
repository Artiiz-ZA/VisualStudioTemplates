﻿using $safeprojectname$.Repositories.Implementations.Models;
using $safeprojectname$.Repositories.Interfaces;
using $safeprojectname$.Repositories.Interfaces.Models;

namespace $safeprojectname$.Repositories.Implementations
{
    public class RepositoryWrapper : IRepositoryWrapper
    {
        private readonly RepositoryContext _repoContext;

        // TODO: Add Interface Objects
        private ITableRepository _tableRepository;

        public RepositoryWrapper(RepositoryContext repositoryContext)
        {
            _repoContext = repositoryContext;
        }

        // TODO: Add interfaces
        public ITableRepository Table => _tableRepository ?? (_tableRepository = new TableRepository(_repoContext));
    }
}