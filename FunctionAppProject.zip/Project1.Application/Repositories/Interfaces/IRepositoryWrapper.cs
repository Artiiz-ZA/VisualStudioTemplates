﻿using $safeprojectname$.Repositories.Interfaces.Models;

namespace $safeprojectname$.Repositories.Interfaces
{
    public interface IRepositoryWrapper
    {
        // TODO: Add all Interface Repositories Here
        ITableRepository Table { get; }
    }
}