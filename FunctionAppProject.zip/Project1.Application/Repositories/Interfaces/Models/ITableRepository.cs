﻿using System;
using System.Collections.Generic;
using CmdbUpdater.Commands.Models;

namespace $safeprojectname$.Repositories.Interfaces.Models
{
    public interface ITableRepository : IRepositoryBase<Table> // TODO: Refactor to actual Table
    {
        IEnumerable<Table> GetAll();
        Table GetById(Guid id);
    }
}